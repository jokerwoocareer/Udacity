# (Prosper Loan Data Exploration)
## by (Michael Woo)


## Dataset

> The original data set contains 113,937 loans with 81 variables on each loan, including loan amount, borrower rate (or interest rate), current loan status, borrower income, and many others.
> After wrangling there are 84,853 loans in the dataset with 69 features. Most variables are numeric, a few are ordered factor variables, and a few are not ordered. For example, the ProsperRating (Alpha) levels are ordered as, from the best to the worst, AA, A, B, C, D, E, HR.


## Summary of Findings

> I found the distribution of the Prosper ratings, the income ranges, the states and the debt to income ratio. I also found relationships between variables. A higher Prosper rating comes with a lower borrower rate and APR. The borrower rate is positively correlated with the estimated effective yield and the estimated loss. A credit card holder is more likely to get a high credit score when he/she utilizes the credit card at a low percentage. The majority of the loans have a 36 months term, and it's also true within each Prosper rating level and each income range. Higher income tends to lead to higher Prosper ratings - on AA level the highest income range has the most count, on A, B, and C level the third highest income range has the most count, and on D, E, and HR level the fourth highest income range has the most count. The positive correlation between the borrower rate and the estimated effective yield can be separated to sub groups by the Prosper ratings, and each sub group seems to have its sub groups which may require more information to find out. The positive correlation between the borrower rate and the estimated loss can be separated to sub groups by the loan status, and in two of the sub groups, completed and charged off, some observations don't fall into the correlation, which may require more information to find out why.


## Key Insights for Presentation

> The presentation includes the relationship between Prosper ratings and borrower rates, which is presented by a violin plot, the relationship between credit card utilization and credit score, which is presented by a heat plot, the relationship between Prosper ratings and the income ranges, which is presented by a clustered bar plot. A distribution of the income ranges is also added to avoid possible misunderstanding. 